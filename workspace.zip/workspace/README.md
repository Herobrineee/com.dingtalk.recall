# Anti Dingtalk Recall

![Anti-996 License](https://img.shields.io/badge/license-Anti--996%20License-blue)

`Issue`、`Pull Requests`、`Star`、`Fork` are all welcomed.

Designed for:

+ Anti-Recall
+ Recall anything

Only support `LSPosed` and `Dingtalk`.

Tested target: Dingtalk `8.3.49.3` (`com.alibaba.android.rimet`, Google Play build shares the same package name).

Build target: Android 17 (`compileSdk 37`, `targetSdk 37`, `minSdk 29`), built with JDK 17 + AGP `9.4.0` + Gradle `9.6.0`.

The module does not rely on a single obfuscated method name. It locates the message
class, hooks every recall-status getter so it keeps returning "not recalled", keeps
`canRecall` returning `true`, and blocks setters that would flag a message as recalled.
All lookups are best-effort, so an unsupported Dingtalk build stays silent instead of
crashing.

When something is not hooked, filter the LSPosed log by `AntiRecall` and open an issue
with the printed `field` / `method` lines.

Enjoy :)
