# User Instruction Memory

This file records user instructions, preferences, and teachings for reference in future interactions.

## Format

### User Instruction Entry
User instruction entries should follow this format:

[User Instruction Summary]
- Date: [YYYY-MM-DD]
- Context: [Mentioned scenario or time]
- Instructions:
  - [Content of user teaching or instruction, described line by line]

### Project Knowledge Entry
Entries discovered by the Agent during task execution should follow this format:

[Project Knowledge Summary]
- Date: [YYYY-MM-DD]
- Context: Discovered by Agent while performing [specific task description]
- Category: [Operations & Deployment|Build Methods|Testing Methods|Troubleshooting & Debugging|Workflow & Collaboration|Environment Configuration]
- Instructions:
  - [Specific knowledge points, described line by line]

## Deduplication Strategy
- Before adding a new entry, check for similar or identical instructions.
- If a duplicate is found, skip the new entry or merge it with the existing one.
- When merging, update the context or date information.
- This helps avoid redundant entries and keeps the memory file tidy.

## Entries

[Project Knowledge Summary]
- Date: 2026-09-16
- Context: Discovered by Agent while building the LSPosed module APK for Dingtalk 8.3.49.3
- Category: Build Methods
- Instructions:
  - Toolchain targets Android 17: `compileSdk = 37`, `targetSdk = 37`, `minSdk = 29`, `buildToolsVersion = "37.0.0"`.
  - Requires AGP 9.4.0 + Gradle 9.6.0 + JDK 17 (AGP 9.1+ is the first line with API 37.0 support; AGP 7/8 builds fail on `compileSdk 37`). CI uses `java-version: 17`.
  - JDK 17 is `/usr/lib/jvm/java-17-openjdk-amd64`.
  - Local build command: `JAVA_HOME=<jdk17> ANDROID_SDK_ROOT=<sdk> GRADLE_USER_HOME=/tmp/opencode/gradle-home /tmp/opencode/gradle-9.6.0/bin/gradle --no-daemon --init-script /tmp/opencode/init-mirror.gradle assembleDebug`. Wrapper `build_apk.sh` is at `/tmp/opencode/build_apk.sh`.
  - Build output APK: `当前工作区/app/build/outputs/apk/debug/app-debug.apk` (debug-signed, installable).

[Project Knowledge Summary]
- Date: 2026-09-16
- Context: Discovered by Agent while making `compileSdk 37` work in this sandbox
- Category: Troubleshooting & Debugging
- Instructions:
  - AGP's local SDK loader only matches the API 37 platform when the directory is `platforms/android-37` AND `source.properties` has an integer `AndroidVersion.ApiLevel=37`. The official `platform-37.0_r02.zip` ships `platforms/android-37.0` with `AndroidVersion.ApiLevel=37.0`, which is NOT recognized; AGP then tries to auto-install from `dl.google.com` (extremely slow, ~2.7 MB/min) and puts it in `platforms/android-37.0-2`.
  - `$SDK/licenses/android-sdk-license` must contain the current hash `24333f8a63b6825ea9c5514f83c2829b004d1fee`, otherwise AGP reports "licences have not been accepted".
  - To re-check SDK resolution fast, run `gradle assembleDebug --dry-run`; if the SDK is unrecognized the run stalls on the download and recreates `$SDK/.temp` and `$SDK/.knownPackages`.
  - APK verification: `$SDK/build-tools/37.0.0/aapt2 dump badging app-debug.apk | grep -E "compileSdk|targetSdk"`.

[Project Knowledge Summary]
- Date: 2026-09-16
- Context: Discovered by Agent while setting up the Android toolchain in this sandbox
- Category: Environment Configuration
- Instructions:
  - `dl.google.com` and `services.gradle.org` are extremely slow from this environment; use mirrors `https://mirrors.cloud.tencent.com/AndroidSDK/` (SDK zips) and `https://mirrors.cloud.tencent.com/gradle/` (Gradle dist) instead.
  - Maven dependencies resolve fast via Aliyun mirrors: `https://maven.aliyun.com/repository/google` and `https://maven.aliyun.com/repository/public`.
  - `apkpure`/`apkcombo`/`apkmirror` are unreachable (SSL_ERROR_SYSCALL); Dingtalk APK cannot be fetched from this environment.
  - Only `androguard` (pure Python) is available for DEX analysis; no jadx/apktool/dex2jar.
